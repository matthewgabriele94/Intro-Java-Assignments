package arraylists;
import java.util.ArrayList;

import vehicles.*;

public class VehicleArraylist {

	public static void main(String[] args) {
		// this ArrayList MUST be parameterized
		ArrayList vehiclesArrayList;
		
		// this is the variable you should retain to compare
		// to the other objects in the arraylist
		Car blueCar;
	}

}
