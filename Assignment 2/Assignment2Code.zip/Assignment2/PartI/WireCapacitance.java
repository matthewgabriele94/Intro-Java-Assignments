
public class WireCapacitance {

	public static double calculateWireCapacitance() {
		
		return -1;
	}
	
	public static void main(String[] args) {
		
	}
}
