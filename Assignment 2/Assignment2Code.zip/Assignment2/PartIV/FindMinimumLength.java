class FindMinimumLength {
    public static int minSubArrayLen(int goal, int[] nums) {
        int minimumLength=0;
        return minimumLength;
    }
    
    public static void main(String[] args) {
    	int[] array1 =   {10,2,3,11};
    	System.out.println(minSubArrayLen(11, array1)); 
    	int[] array2 =   {5, 6, 8, 2};
    	System.out.println(minSubArrayLen(7, array2));
    }
}
