
public class DumbPasswords {

}
