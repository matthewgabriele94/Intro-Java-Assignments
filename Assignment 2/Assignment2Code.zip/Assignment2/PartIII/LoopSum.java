
public class LoopSum {

	
	public static double estimateExponential() {
		
		return -1;
	}
	
	public static void main(String[] args) {	
		System.out.println("e^2 " + Math.pow(Math.E, 2));		
	}
	
}
